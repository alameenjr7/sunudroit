gulp serve-pug --layout=layout1

gulp serve  // This will serve html


https://tusharghate.com/rendering-pug-templates-with-multiple-data-files